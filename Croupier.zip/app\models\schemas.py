"""
Pydantic models for request validation and response serialization.
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime
import re


class OrganizationCreate(BaseModel):
    """Schema for creating a new organization."""
    organization_name: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=8)
    
    @validator('organization_name')
    def validate_organization_name(cls, v):
        """Validate organization name format (alphanumeric, underscores, hyphens)."""
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError(
                'Organization name must contain only alphanumeric characters, '
                'underscores, and hyphens'
            )
        return v.lower()  # Normalize to lowercase
    
    @validator('password')
    def validate_password(cls, v):
        """Validate password complexity."""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class OrganizationUpdate(BaseModel):
    """Schema for updating an organization."""
    new_organization_name: Optional[str] = Field(None, min_length=3, max_length=50)
    new_email: Optional[EmailStr] = None
    new_password: Optional[str] = Field(None, min_length=8)
    
    @validator('new_organization_name')
    def validate_new_organization_name(cls, v):
        """Validate new organization name format."""
        if v is not None:
            if not re.match(r'^[a-zA-Z0-9_-]+$', v):
                raise ValueError(
                    'Organization name must contain only alphanumeric characters, '
                    'underscores, and hyphens'
                )
            return v.lower()
        return v
    
    @validator('new_password')
    def validate_new_password(cls, v):
        """Validate new password complexity."""
        if v is not None:
            if len(v) < 8:
                raise ValueError('Password must be at least 8 characters long')
            if not any(c.isupper() for c in v):
                raise ValueError('Password must contain at least one uppercase letter')
            if not any(c.islower() for c in v):
                raise ValueError('Password must contain at least one lowercase letter')
            if not any(c.isdigit() for c in v):
                raise ValueError('Password must contain at least one digit')
        return v


class OrganizationGet(BaseModel):
    """Schema for retrieving organization details."""
    organization_name: str


class OrganizationDelete(BaseModel):
    """Schema for deleting an organization."""
    organization_name: str


class OrganizationResponse(BaseModel):
    """Schema for organization response."""
    id: str
    organization_name: str
    email: EmailStr
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class AdminLogin(BaseModel):
    """Schema for admin login."""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Schema for JWT token response."""
    access_token: str
    token_type: str = "bearer"
    admin_id: str
    organization_id: str
    organization_name: str


class ErrorResponse(BaseModel):
    """Schema for error responses."""
    detail: str
