# Croupier

A Multi-Tenant Organization Management Service built with FastAPI and MongoDB.

## Project Description

Croupier is a backend service designed to manage organizations in a multi-tenant architecture. It supports organization creation, updates, deletion, admin management, and authentication. The system uses a master database for global metadata and dynamic collections for each organization to ensure data isolation.

## Tech Stack

- **Language:** Python 3.8+
- **Framework:** FastAPI
- **Database:** MongoDB
- **Authentication:** JWT (JSON Web Tokens)
- **Password Hashing:** bcrypt
- **Driver:** pymongo

## Setup Instructions

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd croupier
    ```

2.  **Create a virtual environment:**
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configure Environment Variables:**
    Copy the example environment file and configure it:
    ```bash
    cp .env.example .env
    ```
    
    Then edit `.env` with your settings:
    ```env
    APP_NAME=Croupier
    DEBUG=True
    MONGODB_URL=mongodb://localhost:27017
    MONGODB_DB_NAME=croupier_master
    JWT_SECRET_KEY=your-super-secret-key-change-this
    JWT_ALGORITHM=HS256
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES=60
    ```

5.  **Run MongoDB:**
    Ensure you have a MongoDB instance running locally on port 27017 or update `MONGODB_URL` in `.env`.

## How to Run the Server

Start the application using Uvicorn:

```bash
uvicorn main:app --reload
```

The server will start at `http://localhost:8000`.

## API Documentation

FastAPI provides automatic interactive documentation:

- **Swagger UI:** [http://localhost:8000/docs](http://localhost:8000/docs)
- **ReDoc:** [http://localhost:8000/redoc](http://localhost:8000/redoc)

### Key Endpoints

- **POST /org/create**: Create a new organization.
- **GET /org/get**: Retrieve organization details.
- **PUT /org/update**: Update organization (Auth required).
- **DELETE /org/delete**: Delete organization (Auth required).
- **POST /admin/login**: Admin login to get JWT token.

## Usage Examples

### 1. Create an Organization

```bash
curl -X 'POST' \
  'http://localhost:8000/org/create' \
  -H 'Content-Type: application/json' \
  -d '{
  "organization_name": "acme_corp",
  "email": "admin@acme.com",
  "password": "StrongPassword123"
}'
```

### 2. Login as Admin

```bash
curl -X 'POST' \
  'http://localhost:8000/admin/login' \
  -H 'Content-Type: application/json' \
  -d '{
  "email": "admin@acme.com",
  "password": "StrongPassword123"
}'
```

### 3. Update Organization

```bash
curl -X 'PUT' \
  'http://localhost:8000/org/update' \
  -H 'Authorization: Bearer <YOUR_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
  "organization_name": "acme_corp",
  "new_organization_name": "acme_global"
}'
```

## Architecture and Design

See **[Croupier_Architecture_and_Design.pdf](Croupier_Architecture_and_Design.pdf)** for the high-level diagram, detailed design rationale, and answers to architectural questions.

## Assumptions

- MongoDB is running as a standalone instance (transactions not used).
- Organization names are unique globally.
- "Dynamic collection" implies creating a separate MongoDB collection for each tenant (e.g., `org_acme`).
- Data migration during organization rename is done synchronously (for simplicity). In a production environment with large datasets, this should be an asynchronous background task.
